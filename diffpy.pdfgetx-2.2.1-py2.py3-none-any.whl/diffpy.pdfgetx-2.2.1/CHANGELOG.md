# Release notes

## Version 2.2.1 - 2022-03-23

### Added

- Added new API for accessing intermediate I(Q) plots as properties on
  `PDFGetter` instances via properties following a naming convention of
  `PDFGetter.iq_<i>`, where `i` is a zero-based index of the intermediate I(Q)
  to be returned. That is, rather than a single property returning an array of
  the I(Q)'s that would then be indexed, users may directly name an intermediate
  I(Q) (say, the first I(Q)) via a statement such as `PDFGetter.iq_0`.

### Fixed

- Restored previous API behavior of `PDFGetter.iq` returning the I(Q) plot of
  the data. Since there are now multiple I(Q) plots (one after each subsequent
  background subtraction), this property now returns the final I(Q) data (i.e.,
  the result of applying all background subtractions).
- Fixed formatting of authors list on `PDFgetXNS3_manual.pdf` cover page.


## Version 2.2.0 - 2022-02-10

### Added

- Support for Python 3.10
- Support for Python 3.9
- Unittests for testing CLI functionality.
- Tutorial example for multiple background subtractions (see
  `diffpy.pdfgetx/doc/examples/Multiple_Background_Subtraction`).
- New functionality for allowing multiple backgrounds to be subtracted from a
  dataset accessed via using the plural name equivalent of any previously
  singularly named variable (i.e., `bgscale`->`bgscales`, `backgroundfile`->
  `backgroundfiles`, etc.) in both static config files (i.e., `*.cfg`) and
  interactive plotting sessions. Each set of parameters corresponding to a
  given background subtraction can also be manipulated by a set of sliders
  present in the `tuneconfig` window of an interactive shell session. In total,
  the multiple background subtraction functionality should work identically to
  the previous single background subtraction functionality *except* that the
  multiple background files and initial scale values *cannot* be specified
  through a pure CLI command (i.e., it must be specified either in a config file
  or added/modified during an interactive plotting session).
- Added extra test cases for testing the `PDFGetter` class.
- Added extra test cases for testing the `PDFConfig` class.

### Changed

- Changed `python` versions specified in requirements.txt files to be in the
  range of the respective minor version rather than fixed to the Python X.Y.0
  version
- Python version support policy now follows [NEP 29](https://numpy.org/neps/nep-0029-deprecation_policy.html)
- Changed versions used in `conda-recipe/build.sh` to reflect currently
  supported Python versions.
- Changed Sphinx dependency `m2r` to `m2r2`.
- Added Connor J. Bracy and Zach Thatcher to contributors in AUTHORS.txt
- Added Connor J. Bracy to internal authors list and `PDFgetXNS3_manual.pdf`

### Removed

- Support for Python 3.5 and 3.6.


## Version 2.1.2 - 2021-12-24

### Fixed

- Fixed the command provided to the users in the installation instructions which
  incorrectly instructed them to setup a Python environment in which `pdfgetx`
  could be installed by using the flag `--python=3.8` to the correct usage of
  this flag as `python=3.8`.


## Version 2.1.1 - 2020-09-01

### Added

- Support for Python 3.8

## Version 2.1.0 – 2020-07-15

### Added

- New mode `sas` for processing Small Angle Scattering data and
  for using custom scattering factors.
- *qmax-pushes-qmin* coupling of sliders in the `tuneconfig` tool.
- New program `pdfgets3` and IPython magic `%pdfgets3`.

### Changed

- Software distribution format to a universal Python wheel.
- `tuneconfig` dialog to access full Q-range with all *qmin*, *qmax*, and
  *qmaxinst* sliders.  Increased range for the *rpoly* slider.

### Deprecated

- Software distribution in setuptools egg package.

### Removed

- Support for Python 3.4.

### Fixed

- Support backslash in the `--find` option path argument on Windows.
  Both forward and back slashes are allowed on Windows, but other
  platforms must use forward slash.
- Recipe for platform-dependent Anaconda package.
- Bogus test failure when installed in symlinked directory.


## Version 2.0.0 – 2018-11-02

### Added

- New mode `neutron` for processing constant-wavelength
  neutron scattering data.
- Correction for an offset of diffractometer zero angle.
- Configuration parameter `twothetazero` and command-line option
  `--twothetazero` for position of the actual zero angle
  in diffractometer degrees.
- New program `pdfgetn3` and IPython magic `%pdfgetn3`.
- Separate configuration file `pdfgetn3.cfg` for the `pdfgetn3` program.
- New sub-package `diffpy.pdfgetx.apps` for entry points to all programs.
- Table of electron scattering factors from E. J. Kirkland,
  Advanced Computing in Electron Microscopy.
- The `+` operator for additive pattern groups when matching input files
  with `pdfgetx3 --find`.
- An optional slash-containing entry, e.g., `dir/`, to set the search path
  for `pdfgetx3 --find`.  Each pattern group may have one path entry which
  affects the current and subsequent pattern groups.  Pattern groups that
  have only the path entry reuse the previous file patterns, for example,
  `dir1/ .dat$ + dir2/ + dir3/`.
- The `dotfiles` flag argument to `functs.findfiles` to also find
  dot-starting files without an explicit pattern.
- Support for Python 3.7.
- Tutorial examples for constant-wavelength neutron diffraction data.

### Changed

- Initialization arguments of `PDFConfig` to set initial configuration values.
- `path` argument of `functs.findfiles` to give one search path instead
  of a list of paths.
- `pdfgetx3 --find` to search only the current directory and stop searching
  in `--datapath`.
- Improved PDF accuracy by removing repeated Q-grid interpolation.
- Handling of dot files by `pdfgetx3 --find` and the `functs.findfiles`
  function.  The dotfiles are by default ignored unless explicitly selected
  by a `"^."` pattern.
- Return type of `functs.findfiles` from IPython `SList` to a simple `list`.
- Rename camel case interactive functions to lowercase, i.e., to `loaddata`,
  `processfiles`, `clearsession`.
- Use `config.datapath` lookup in `processfiles(filename)`.

### Deprecated

- Function `cromermann.felectronatq` for electron scattering
  factors calculation using Mott-Bethe approximate formula.
- IPython extension module `diffpy.pdfgetx.ipy_pdfgetx3`.
  Use `diffpy.pdfgetx.ipy_magics` instead.
- Camel case functions `loadData`, `processFiles`, `clearSession`.

### Removed

- Support for Python 2.6.
- Processing of environment variable `PDFGETX3PATH`.
- Support for IPython 0.x.
- Obsolete variable `__gitsha__` from the `version` module.
- Processing of command line options in `PDFConfig` class.
- Implicit loading of configuration files in `PDFConfig` instantiation.

### Fixed

- Import of all objects from `matplotlib.pyplot` into
  an interactive session started by `plotdata`.
- Inaccurate G interpolation when rstep is comparable to `pi / qmax`.
- Lone anchor patterns `^`, `$` to match everything.


## Version 1.2 – 2018-01-12

### Added

- Support for Python 3.4, 3.5, 3.6 in addition to Python 2.6 and 2.7.
- Support for [IPython 5.0](https://ipython.org) with preserved
  compatibility with IPython 0.10 and later.
- Support for [matplotlib 2.0](https://matplotlib.org).
- New option `--log=LOG` for the `plotdata` program to set logarithmic
  scale for either of *x* or *y* axis.  The `plotdata()` function learnt
  a new `log` argument with the same purpose.
- New argument `ax` for the `plotdata()` function that select a specific
  matplotlib axis for plotting.
- Support for Unicode filenames and values in the `config`
  interactive variable.
- Processing of parentheses and fractional stoichiometries in chemical
  formulas as in `Pb (Ti Zr)1/2 O3`.
- Explanatory error message when PDFgetX3 was installed for
  unsupported Python.

### Changed

- The egg package file was enhanced to support all Python
  versions.  The software is now distributed in a single
  egg rather than multiple eggs per each Python version.
- PDFgetX3 option `--force` to take a boolean argument
  (`yes`, `no`, `true`, etc.) or `once`.  The configuration
  parameter `force` can be likewise set to a bool or to
  a string `"once"`.  This enables a safer one-time
  overwrite of existing output files.
- Plot labels to use a proper Unicode "Å" (Ångström) symbols.
  The "Å" symbol is also used within units in output files.
- The `usecols` argument of the `loadData()` function to also
  accept scalars, open-end `slice` objects and string-denoted
  slices such as `"1:3"` or `"1:"`.
- The `plotdata` program and `plotdata()` function to accept
  open-end slices for the y-columns selection.
- The IPython magic function `%pdfgetx3` to set the `_exit_code`
  variable as do generic shell commands run from IPython.
- Inline documentation to use NumPy-style Napoleon format,
  which is human readable and can be included in the manual.
- Release scripts to build software package bundles and
  documentation in binary-reproducible way.

### Deprecated

- Compatibility with Python 2.6.
- Support for IPython 0.x.
- Variable `__gitsha__` in the `version` module which was renamed
  to `__git_commit__`.

### Removed

- The `hold` argument of the `plotdata()` function,
  because it was deprecated in matplotlib.
- Support for multiple x-columns in `plotdata` program and
  `plotdata()` function.
- Import of all objects from `numpy` module into the interactive
  session.  NumPy is available under the `np` name instead.

### Fixed

- Avoid duplicate ".gr.gr" extension when `pdfgetx3` is run
  with option `--output=f.gr`.
- Crash on loading custom configuration section from a local
  file, when that section is missing in global configuration.
- Missing checkbox in the `tuneconfig` dialog caused by matplotlib bug.
