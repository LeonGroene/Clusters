#!/usr/bin/env python
##############################################################################
#
# diffpy            by DANSE Diffraction group
#                   Simon J. L. Billinge
#                   (c) 2008 Trustees of the Columbia University
#                   in the City of New York.  All rights reserved.
#
# File coded by:    Pavol Juhas
#
# See AUTHORS.txt for a list of people who contributed.
# See LICENSENOTICE.txt for license information.
#
##############################################################################

"""diffpy - tools for structure analysis by diffraction.

Blank namespace package.
"""


from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)


# End of file
