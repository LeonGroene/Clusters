#!/usr/bin/env python
##############################################################################
#
# diffpy.pdfgetx    by DANSE Diffraction group
#                   Simon J. L. Billinge
#                   (c) 2008 Trustees of the Columbia University
#                   in the City of New York.  All rights reserved.
#
# File coded by:    Timur Dykhne
#
# See AUTHORS.txt for a list of people who contributed.
# See LICENSENOTICE.txt for license information.
#
##############################################################################

"""\
Tools for extracting X-ray and neutron PDFs from powder diffraction data.
"""

# adjust what shows in package pydoc
__all__ = ['PDFConfig', 'loadPDFConfig', 'PDFGetter', 'Transformation',
           'loaddata', 'findfiles']

import sys
import os.path

# Prologue -------------------------------------------------------------------

# canonical path for resolving location of data files

_MYDIR = os.path.abspath(__path__[0])

# adjust __path__ if this is installed from a multi-version pyc-only egg

_pyxy = '.'.join(str(i) for i in sys.version_info[:2])
if not os.path.isfile(os.path.join(_MYDIR, 'version.py')):
    __path__.append(_MYDIR + _pyxy)     # pragma: no cover

# consistency check for egg installation -------------------------------------

try:
    from diffpy.pdfgetx.version import __version__ as v
    del v
except ImportError:     # pragma: no cover
    if len(__path__) == 1:
        raise
    emsg = ("Python %s is not supported.\n\n"
            "Please reinstall using a supported Python version.") % _pyxy
    raise ImportError(emsg)

del _pyxy

# ----------------------------------------------------------------------------

# package version
from diffpy.pdfgetx.version import __version__

# some convenience imports
from diffpy.pdfgetx.pdfconfig import PDFConfig, loadPDFConfig
from diffpy.pdfgetx.pdfgetter import PDFGetter
from diffpy.pdfgetx.transformation import Transformation
from diffpy.pdfgetx.functs import loaddata, findfiles

# TODO - replace with  `loadData = loaddata` for version 3.0
from diffpy.pdfgetx.functs import loadData

# silence pyflakes checker
assert __version__ or True
assert loadData

# End of file
