These X-ray data were measured from a mixture of Si and Ni powders
with weight ratio of Si 90%, Ni 10%.  This corresponds to molar ratio
of Si 0.95  Ni 0.05 which is used as composition for PDF processing.
