diffpy.pdfgetx - command line programs and Python library for producing
pair distribution functions from X-ray and neutron powder diffraction data


REQUIREMENTS

The software requires Python 3.10, 3.9, 3.8, 3.7 or 2.7 and third-party
Python libraries setuptools, six, NumPy, matplotlib, and IPython.
On Linux operating systems they can be obtained from the system software
package repository.  On Windows and MAC it is advisable to install either
the Anaconda Python, Enthought Canopy or PythonXY distributions, which
include all the necessary software.


INSTALLATION

To install this software from a Python wheel distribution format execute

    pip install ./diffpy.pdfgetx-VERSION.whl

where VERSION must be replaced to match the actual filename.
It is critical that the pip command is from a supported Python
version listed above otherwise the program would not work.

To install this software from sources run

    python setup.py install

Either of these methods would install Python library diffpy.pdfgetx
and three command-line applications pdfgetx3, pdfgetn3 and plotdata.

By default the files are installed in system directories,
which may be only writeable by the root.  See the usage info
"pip install --help" for options to install as a regular user
to different location.  Note that installation to non-standard
directories may require adjustments to the PATH and PYTHONPATH
environment variables.

See the included manual for more installation details and for
user instructions.

------------------------------------------------------------------------------

For more information about the diffpy.pdfgetx suite and its PDFgetX3 and
PDFgetN3 programs contact Prof. Simon Billinge at sb2896@columbia.edu.
